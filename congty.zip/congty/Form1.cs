﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace congty
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        XmlDocument doc = new XmlDocument();
        string tentep = @"E:\Ki1-Nam4\Tichhop\ex\congty\dsnhanvien.xml";
        int d = 0;

        private void Hienthi()
        {
            dsnhanvien.Rows.Clear();
            doc.Load(tentep);
            XmlNodeList ct = doc.SelectNodes("/congty/nhanvien");

            dsnhanvien.ColumnCount = 5;
            dsnhanvien.Rows.Add();
            int sd = 0;

            foreach (XmlNode nv in ct)
            {
                XmlNode ma_nv = nv.SelectSingleNode("manv");
                dsnhanvien.Rows[sd].Cells[0].Value = ma_nv.InnerText.ToString();
                XmlNode ho_ten = nv.SelectSingleNode("hoten");
                dsnhanvien.Rows[sd].Cells[1].Value = ho_ten.InnerText.ToString();
                XmlNode que = nv.SelectSingleNode("quequan");
                dsnhanvien.Rows[sd].Cells[2].Value = que.InnerText.ToString();
                XmlNode ngoai_ngu = nv.SelectSingleNode("ngoaingu/@name");
                dsnhanvien.Rows[sd].Cells[3].Value = ngoai_ngu.InnerText.ToString();
                XmlNode trinh_do = nv.SelectSingleNode("ngoaingu/trinhdo");
                dsnhanvien.Rows[sd].Cells[4].Value = trinh_do.InnerText.ToString();
                dsnhanvien.Rows.Add();
                sd++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Hienthi();
        }

        private void dsnhanvien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            d = e.RowIndex;
            txtMa.Text= dsnhanvien.Rows[d].Cells[0].Value.ToString();
            txtName.Text = dsnhanvien.Rows[d].Cells[1].Value.ToString();
            txtQue.Text = dsnhanvien.Rows[d].Cells[2].Value.ToString();
            txtNgoaingu.Text = dsnhanvien.Rows[d].Cells[3].Value.ToString();
            txtTrinhdo.Text = dsnhanvien.Rows[d].Cells[4].Value.ToString();

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;

            XmlNode check = goc.SelectSingleNode("/congty/nhanvien[manv='" + txtMa.Text + "']");
            if (check == null)
            {

                XmlNode nhan_vien = doc.CreateElement("nhanvien");
                XmlNode ma_nv = doc.CreateElement("manv");
                ma_nv.InnerText = txtMa.Text;
                nhan_vien.AppendChild(ma_nv);
                XmlNode ho_ten = doc.CreateElement("hoten");
                ho_ten.InnerText = txtName.Text;
                nhan_vien.AppendChild(ho_ten);
                XmlNode que = doc.CreateElement("quequan");
                que.InnerText = txtQue.Text;
                nhan_vien.AppendChild(que);

                XmlNode ngoai_ngu = doc.CreateElement("ngoaingu");
                XmlAttribute name = doc.CreateAttribute("name");
                name.InnerText = txtNgoaingu.Text;
                ngoai_ngu.Attributes.Append(name);
                XmlNode trinh_do = doc.CreateElement("trinhdo");
                trinh_do.InnerText = txtTrinhdo.Text;
                ngoai_ngu.AppendChild(trinh_do);

                nhan_vien.AppendChild(ngoai_ngu);
                goc.AppendChild(nhan_vien);

                doc.Save(tentep);
                Hienthi();
            }
            else
            {
                MessageBox.Show("Trung nhan vien");
            }

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;
            XmlNode nhan_vien_cu = doc.SelectSingleNode("/congty/nhanvien[manv='" + txtMa.Text + "']");
            XmlNode nhan_vien_sua = doc.CreateElement("nhanvien");
            XmlNode quequan_check = nhan_vien_cu.SelectSingleNode("quequan");
            XmlNode name_check = nhan_vien_cu.SelectSingleNode("ngoaingu/@name");
            if(quequan_check.InnerText.Equals("Ha Noi") && name_check.InnerText.Equals("Tieng anh"))
            {
                

                
                XmlNode ma_nv = doc.CreateElement("manv");
                ma_nv.InnerText = txtMa.Text;
                nhan_vien_sua.AppendChild(ma_nv);
                XmlNode ho_ten = doc.CreateElement("hoten");
                ho_ten.InnerText = txtName.Text;
                nhan_vien_sua.AppendChild(ho_ten);
                XmlNode que = doc.CreateElement("quequan");
                que.InnerText = txtQue.Text;
                nhan_vien_sua.AppendChild(que);

                XmlNode ngoai_ngu = doc.CreateElement("ngoaingu");
                XmlAttribute name = doc.CreateAttribute("name");
                name.InnerText = txtNgoaingu.Text;
                ngoai_ngu.Attributes.Append(name);
                XmlNode trinh_do = doc.CreateElement("trinhdo");
                trinh_do.InnerText = txtTrinhdo.Text;
                ngoai_ngu.AppendChild(trinh_do);
                nhan_vien_sua.AppendChild(ngoai_ngu);

                goc.ReplaceChild(nhan_vien_sua,nhan_vien_cu);
          

                doc.Save(tentep);
                Hienthi();
            }else
            {
                MessageBox.Show("Khong sua dc");
            }
            

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;

            XmlNodeList check = goc.SelectNodes("/congty/nhanvien[quequan='" + txtQue.Text + "']");
            if(check.Count >0)
            {
                foreach(XmlNode nv in check)
                {
                    goc.RemoveChild(nv);
                   
                }
                doc.Save(tentep);
                Hienthi();
            }
            else
            {
                MessageBox.Show("Khong co noi sinh nay");
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;
            XmlNodeList nhan_vien_tim = goc.SelectNodes("/congty/nhanvien[hoten='" + txtName.Text + "']");

            dsnhanvien.Rows.Clear();
            dsnhanvien.ColumnCount = 5;
            dsnhanvien.Rows.Add();
            int sd = 0;
            if (nhan_vien_tim.Count > 0  )
            {
                foreach(XmlNode nv in nhan_vien_tim)
                {
                    XmlNode ma_nv = nv.SelectSingleNode("manv");
                    dsnhanvien.Rows[sd].Cells[0].Value = ma_nv.InnerText.ToString();
                    //XmlNode ho_ten = nv.SelectSingleNode("hoten");
                    dsnhanvien.Rows[sd].Cells[1].Value = txtName.Text;
                    XmlNode que = nv.SelectSingleNode("quequan");
                    dsnhanvien.Rows[sd].Cells[2].Value = que.InnerText.ToString();
                    XmlNode ngoai_ngu = nv.SelectSingleNode("ngoaingu/@name");
                    dsnhanvien.Rows[sd].Cells[3].Value = ngoai_ngu.InnerText.ToString();
                    XmlNode trinh_do = nv.SelectSingleNode("ngoaingu/trinhdo");
                    dsnhanvien.Rows[sd].Cells[4].Value = trinh_do.InnerText.ToString();
                    dsnhanvien.Rows.Add();
                    sd++;
                }
                MessageBox.Show("DA TIM THAY " + nhan_vien_tim.Count + " nhân viên");
            }
            else
            {
                MessageBox.Show("ko TIM THAY");
            }
        }

        private void Tim_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;
            XmlNode nhan_vien_tim = goc.SelectSingleNode("/congty/nhanvien[manv='" + txtMa.Text + "']");

            dsnhanvien.Rows.Clear();
            dsnhanvien.ColumnCount = 5;
            
            if (nhan_vien_tim != null)
            {
                dsnhanvien.Rows.Add();
                XmlNode ma_nv = nhan_vien_tim.SelectSingleNode("manv");
                    dsnhanvien.Rows[0].Cells[0].Value = ma_nv.InnerText.ToString();
                    XmlNode ho_ten = nhan_vien_tim.SelectSingleNode("hoten");
                    dsnhanvien.Rows[0].Cells[1].Value = ho_ten.InnerText.ToString();
                    XmlNode que = nhan_vien_tim.SelectSingleNode("quequan");
                    dsnhanvien.Rows[0].Cells[2].Value = que.InnerText.ToString();
                    XmlNode ngoai_ngu = nhan_vien_tim.SelectSingleNode("ngoaingu/@name");
                    dsnhanvien.Rows[0].Cells[3].Value = ngoai_ngu.InnerText.ToString();
                    XmlNode trinh_do = nhan_vien_tim.SelectSingleNode("ngoaingu/trinhdo");
                    dsnhanvien.Rows[0].Cells[4].Value = trinh_do.InnerText.ToString();
              
                MessageBox.Show("DA TIM THAY ");
            }
            else
            {
                MessageBox.Show("ko TIM THAY");
            }
        }
    
    }
}
