﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace DoDucLong_2022603232
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        XmlDocument doc = new XmlDocument();
        string tentep = @"E:\Ki1-Nam4\Tichhop\DoDucLong_2022603232\dsnhanvien.xml";
        int d;

        private void HienThi()
        {
            dsNhanvien.Rows.Clear();
            doc.Load(tentep);

            XmlNodeList DS = doc.SelectNodes("/ds/nhanvien");
            int sd = 0;
            dsNhanvien.ColumnCount = 4;
            dsNhanvien.Rows.Add();

            foreach (XmlNode nv in DS)
            {
                XmlNode ma_nv = nv.SelectSingleNode("@manv");
                dsNhanvien.Rows[sd].Cells[0].Value = ma_nv.InnerText.ToString();

                XmlNode ho = nv.SelectSingleNode("hoten/ho");
                dsNhanvien.Rows[sd].Cells[1].Value = ho.InnerText.ToString();

                XmlNode ten = nv.SelectSingleNode("hoten/ten");
                dsNhanvien.Rows[sd].Cells[2].Value = ten.InnerText.ToString();

                XmlNode dc = nv.SelectSingleNode("diachi");
                dsNhanvien.Rows[sd].Cells[3].Value = dc.InnerText.ToString();

                dsNhanvien.Rows.Add();
                sd++;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThi();
        }

        private void dsNhanvien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            d = e.RowIndex;
            txtMa.Text = dsNhanvien.Rows[d].Cells[0].Value.ToString();
            txtHo.Text = dsNhanvien.Rows[d].Cells[1].Value.ToString();
            txtTen.Text = dsNhanvien.Rows[d].Cells[2].Value.ToString();
            txtDc.Text = dsNhanvien.Rows[d].Cells[3].Value.ToString();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;


            XmlNode nv = doc.CreateElement("nhanvien");
            XmlAttribute ma_nv = doc.CreateAttribute("manv");
            ma_nv.InnerText = txtMa.Text;
            nv.Attributes.Append(ma_nv);

            //  tao nut hoten
            XmlNode ho_ten = doc.CreateElement("hoten");


            XmlNode ho = doc.CreateElement("ho");
            ho.InnerText = txtHo.Text;
            ho_ten.AppendChild(ho);


            XmlNode ten = doc.CreateElement("ten");
            ten.InnerText = txtTen.Text;
            ho_ten.AppendChild(ten);


            //bosung hoten vao nv
            nv.AppendChild(ho_ten);


            XmlNode dia_chi = doc.CreateElement("diachi");
            dia_chi.InnerText = txtDc.Text;
            nv.AppendChild(dia_chi);


            goc.AppendChild(nv);


            doc.Save(tentep);
            HienThi();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;

            //xacdinh nv can sua
            XmlNode nv_cu = goc.SelectSingleNode("/ds/nhanvien[@manv='" + txtMa.Text + "']");

            XmlNode nv_moi = doc.CreateElement("nhanvien");

            XmlAttribute ma_nv = doc.CreateAttribute("manv");
            ma_nv.InnerText = txtMa.Text;
            nv_moi.Attributes.Append(ma_nv);

            //  tao nut hoten
            XmlNode ho_ten = doc.CreateElement("hoten");

            XmlNode ho = doc.CreateElement("ho");
            ho.InnerText = txtHo.Text;
            ho_ten.AppendChild(ho);

            XmlNode ten = doc.CreateElement("ten");
            ten.InnerText = txtTen.Text;
            ho_ten.AppendChild(ten);

            //bosung hoten vao nv
            nv_moi.AppendChild(ho_ten);

            XmlNode dia_chi = doc.CreateElement("diachi");
            dia_chi.InnerText = txtDc.Text;
            nv_moi.AppendChild(dia_chi);

            goc.ReplaceChild(nv_moi, nv_cu);

            doc.Save(tentep);
            HienThi();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;

            //xd nut can xoa
            XmlNode nv_canxoa = goc.SelectSingleNode("/ds/nhanvien[@manv='" + txtMa.Text + "']");
            goc.RemoveChild(nv_canxoa);

            doc.Save(tentep);
            HienThi();

        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            doc.Load(tentep);
            XmlElement goc = doc.DocumentElement;

            // tìm node nhân viên theo mã
            XmlNode nv_tim = goc.SelectSingleNode("/ds/nhanvien[@manv='" + txtMa.Text + "']");

            dsNhanvien.Rows.Clear();
            dsNhanvien.ColumnCount = 4;

            // nếu tìm thấy
            if (nv_tim != null)
            {
                dsNhanvien.Rows.Add();
                XmlNode ho = nv_tim.SelectSingleNode("hoten/ho");
                XmlNode ten = nv_tim.SelectSingleNode("hoten/ten");
                XmlNode dc = nv_tim.SelectSingleNode("diachi");


                dsNhanvien.Rows[0].Cells[0].Value = txtMa.Text;
                dsNhanvien.Rows[0].Cells[1].Value = ho.InnerText;
                dsNhanvien.Rows[0].Cells[2].Value = ten.InnerText;
                dsNhanvien.Rows[0].Cells[3].Value = dc.InnerText;
                MessageBox.Show("Đã tìm thấy nhân viên!");
            }
            else
            {
                MessageBox.Show("Không tìm thấy nhân viên!");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
